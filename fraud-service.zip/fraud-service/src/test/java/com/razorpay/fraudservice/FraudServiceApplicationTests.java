package com.razorpay.fraudservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
